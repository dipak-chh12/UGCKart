import React, { useState, useEffect } from 'react';
import { 
  Video, 
  Upload, 
  X, 
  Instagram, 
  Youtube, 
  Twitter, 
  Facebook,
  Plus,
  Trash2,
  Eye,
  ArrowLeft,
  Camera,
  MapPin,
  DollarSign,
  Users,
  Star,
  Check,
  ChevronDown,
  Link,
  Tag,
  Globe
} from 'lucide-react';

interface CreatorProfileProps {
  onBack: () => void;
}

interface SocialLink {
  id: string;
  platform: string;
  url: string;
  followers?: string;
}

interface PortfolioItem {
  id: string;
  type: 'upload' | 'link';
  title: string;
  brandName: string;
  url?: string;
  file?: File;
}

const CreatorProfile: React.FC<CreatorProfileProps> = ({ onBack }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);

  // Form data state
  const [formData, setFormData] = useState({
    // Step 1: Basic Information
    name: '',
    username: 'creator_user123', // Simulated from signup
    activePlatforms: [] as string[],
    instagramLink: '',
    instagramFollowers: '',
    socialLinks: [] as SocialLink[],
    phoneNumber: '',
    businessEmail: '',
    
    // Step 2: Experience & Portfolio
    brandsCollaborated: [] as string[],
    brandInput: '',
    portfolioItems: [] as PortfolioItem[],
    overviewVideo: '',
    expertise: [] as string[],
    minBudget: '',
    
    // Step 3: Profile Photo
    profileImage: null as File | null,
    profileImagePreview: ''
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [showPlatformDropdown, setShowPlatformDropdown] = useState(false);
  const [showExpertiseDropdown, setShowExpertiseDropdown] = useState(false);
  const [expertiseSearch, setExpertiseSearch] = useState('');

  // Platform options
  const platforms = [
    { id: 'facebook', name: 'Facebook', icon: Facebook },
    { id: 'instagram', name: 'Instagram', icon: Instagram },
    { id: 'youtube', name: 'YouTube', icon: Youtube },
    { id: 'tiktok', name: 'TikTok', icon: Video }
  ];

  // Social media platforms for optional links
  const socialPlatforms = [
    'Instagram', 'YouTube', 'Facebook', 'Twitter', 'TikTok', 'LinkedIn', 'Pinterest', 'Snapchat'
  ];

  // Expertise categories
  const expertiseCategories = [
    'Fashion & Apparel', 'Beauty & Cosmetics', 'Health & Fitness', 'Food & Beverage',
    'Technology & Gadgets', 'Home & Garden', 'Travel & Tourism', 'Automotive',
    'Sports & Recreation', 'Books & Literature', 'Music & Entertainment', 'Art & Crafts',
    'Jewelry & Accessories', 'Baby & Kids', 'Pet Care', 'Gaming', 'Education',
    'Finance & Investment', 'Real Estate', 'Photography', 'Lifestyle', 'Wellness',
    'Skincare', 'Haircare', 'Makeup', 'Footwear', 'Bags & Luggage', 'Watches',
    'Electronics', 'Mobile Accessories', 'Kitchen & Dining', 'Furniture',
    'Outdoor & Adventure', 'Sustainable Living', 'Luxury Goods', 'Vintage & Antiques'
  ];

  // Auto-save functionality
  useEffect(() => {
    const savedData = localStorage.getItem('creatorProfileData');
    if (savedData) {
      const parsed = JSON.parse(savedData);
      setFormData(prev => ({ ...prev, ...parsed }));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('creatorProfileData', JSON.stringify(formData));
  }, [formData]);

  // Simulate Instagram follower fetch
  const fetchInstagramFollowers = async (url: string) => {
    if (url.includes('instagram.com/')) {
      // Simulate API call
      setTimeout(() => {
        const followers = Math.floor(Math.random() * 100000) + 1000;
        setFormData(prev => ({
          ...prev,
          instagramFollowers: followers.toLocaleString()
        }));
      }, 1000);
    }
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (formErrors[field]) {
      setFormErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }

    // Auto-fetch Instagram followers
    if (field === 'instagramLink' && value) {
      fetchInstagramFollowers(value);
    }
  };

  const togglePlatform = (platformId: string) => {
    const currentPlatforms = formData.activePlatforms;
    const newPlatforms = currentPlatforms.includes(platformId)
      ? currentPlatforms.filter(p => p !== platformId)
      : [...currentPlatforms, platformId];
    
    handleInputChange('activePlatforms', newPlatforms);
  };

  const addBrandTag = () => {
    if (formData.brandInput.trim()) {
      const newBrands = [...formData.brandsCollaborated, formData.brandInput.trim()];
      setFormData(prev => ({
        ...prev,
        brandsCollaborated: newBrands,
        brandInput: ''
      }));
    }
  };

  const removeBrandTag = (index: number) => {
    const newBrands = formData.brandsCollaborated.filter((_, i) => i !== index);
    handleInputChange('brandsCollaborated', newBrands);
  };

  const addSocialLink = () => {
    const newLink: SocialLink = {
      id: Date.now().toString(),
      platform: 'Instagram',
      url: '',
      followers: ''
    };
    handleInputChange('socialLinks', [...formData.socialLinks, newLink]);
  };

  const updateSocialLink = (id: string, field: string, value: string) => {
    const updatedLinks = formData.socialLinks.map(link =>
      link.id === id ? { ...link, [field]: value } : link
    );
    handleInputChange('socialLinks', updatedLinks);
  };

  const removeSocialLink = (id: string) => {
    const updatedLinks = formData.socialLinks.filter(link => link.id !== id);
    handleInputChange('socialLinks', updatedLinks);
  };

  const addPortfolioItem = () => {
    const newItem: PortfolioItem = {
      id: Date.now().toString(),
      type: 'link',
      title: '',
      brandName: '',
      url: ''
    };
    handleInputChange('portfolioItems', [...formData.portfolioItems, newItem]);
  };

  const updatePortfolioItem = (id: string, field: string, value: any) => {
    const updatedItems = formData.portfolioItems.map(item =>
      item.id === id ? { ...item, [field]: value } : item
    );
    handleInputChange('portfolioItems', updatedItems);
  };

  const removePortfolioItem = (id: string) => {
    const updatedItems = formData.portfolioItems.filter(item => item.id !== id);
    handleInputChange('portfolioItems', updatedItems);
  };

  const toggleExpertise = (category: string) => {
    const currentExpertise = formData.expertise;
    const newExpertise = currentExpertise.includes(category)
      ? currentExpertise.filter(e => e !== category)
      : [...currentExpertise, category];
    
    handleInputChange('expertise', newExpertise);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFormData(prev => ({
          ...prev,
          profileImage: file,
          profileImagePreview: e.target?.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const validateStep = (step: number) => {
    const errors: Record<string, string> = {};

    if (step === 1) {
      if (!formData.name.trim()) errors.name = 'Name is required';
      if (!formData.instagramLink.trim()) errors.instagramLink = 'Instagram link is required';
      if (!formData.phoneNumber.trim()) errors.phoneNumber = 'Phone number is required';
      if (!formData.businessEmail.trim()) errors.businessEmail = 'Business email is required';
      else if (!/\S+@\S+\.\S+/.test(formData.businessEmail)) {
        errors.businessEmail = 'Please enter a valid email';
      }
    }

    if (step === 2) {
      if (formData.expertise.length === 0) errors.expertise = 'Please select at least one area of expertise';
      if (!formData.minBudget.trim()) errors.minBudget = 'Minimum budget is required';
    }

    if (step === 3) {
      if (!formData.profileImage) errors.profileImage = 'Profile image is required';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep === 1) {
      onBack();
    } else {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = async () => {
    if (!validateStep(3)) return;

    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      setSubmissionSuccess(true);
      
      // Clear saved data
      localStorage.removeItem('creatorProfileData');
      
    } catch (error) {
      setFormErrors({ submit: 'Something went wrong. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const filteredExpertise = expertiseCategories.filter(category =>
    category.toLowerCase().includes(expertiseSearch.toLowerCase())
  );

  const renderProgressBar = () => (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm font-medium text-gray-600">Step {currentStep} of 3</span>
        <span className="text-sm text-gray-500">
          {currentStep === 1 ? 'Basic Information' : 
           currentStep === 2 ? 'Experience & Portfolio' : 'Profile Photo'}
        </span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div 
          className="bg-[#8349f0] h-2 rounded-full transition-all duration-300"
          style={{ width: `${(currentStep / 3) * 100}%` }}
        ></div>
      </div>
    </div>
  );

  const renderStep1 = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Basic Information</h2>
      
      {/* Name */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Name *</label>
        <input
          type="text"
          value={formData.name}
          onChange={(e) => handleInputChange('name', e.target.value)}
          placeholder="Enter your full name"
          className={`w-full bg-white/50 backdrop-blur-sm border rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 ${
            formErrors.name ? 'border-red-500' : 'border-gray-200'
          }`}
        />
        {formErrors.name && <p className="text-red-500 text-sm mt-1">{formErrors.name}</p>}
      </div>

      {/* Username */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
        <input
          type="text"
          value={formData.username}
          disabled
          className="w-full bg-gray-100 border border-gray-200 rounded-xl py-3 px-4 text-gray-500 cursor-not-allowed"
        />
        <p className="text-xs text-gray-500 mt-1">Username is auto-generated from signup data</p>
      </div>

      {/* Active Platforms */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Active Platforms</label>
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowPlatformDropdown(!showPlatformDropdown)}
            className="w-full bg-white/50 backdrop-blur-sm border border-gray-200 rounded-xl py-3 px-4 flex items-center justify-between focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300"
          >
            <span className="text-gray-700">
              {formData.activePlatforms.length === 0 
                ? 'Select platforms' 
                : `${formData.activePlatforms.length} platform(s) selected`}
            </span>
            <ChevronDown className="h-5 w-5 text-gray-400" />
          </button>
          
          {showPlatformDropdown && (
            <div className="absolute z-10 w-full mt-1 bg-white/90 backdrop-blur-md border border-gray-200 rounded-xl shadow-lg">
              {platforms.map((platform) => {
                const Icon = platform.icon;
                const isSelected = formData.activePlatforms.includes(platform.id);
                
                return (
                  <div
                    key={platform.id}
                    onClick={() => togglePlatform(platform.id)}
                    className="flex items-center space-x-3 p-3 hover:bg-gray-50 cursor-pointer first:rounded-t-xl last:rounded-b-xl"
                  >
                    <div className={`w-5 h-5 border-2 rounded flex items-center justify-center ${
                      isSelected ? 'bg-[#8349f0] border-[#8349f0]' : 'border-gray-300'
                    }`}>
                      {isSelected && <Check className="h-3 w-3 text-white" />}
                    </div>
                    <Icon className="h-5 w-5 text-gray-600" />
                    <span className="text-gray-700">{platform.name}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Instagram Link */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Instagram Link *</label>
        <input
          type="url"
          value={formData.instagramLink}
          onChange={(e) => handleInputChange('instagramLink', e.target.value)}
          placeholder="https://instagram.com/yourusername"
          className={`w-full bg-white/50 backdrop-blur-sm border rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 ${
            formErrors.instagramLink ? 'border-red-500' : 'border-gray-200'
          }`}
        />
        {formData.instagramFollowers && (
          <p className="text-sm text-green-600 mt-1">
            <Users className="h-4 w-4 inline mr-1" />
            {formData.instagramFollowers} followers detected
          </p>
        )}
        {formErrors.instagramLink && <p className="text-red-500 text-sm mt-1">{formErrors.instagramLink}</p>}
      </div>

      {/* Optional Social Links */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <label className="block text-sm font-medium text-gray-700">Optional Social Links</label>
          <button
            type="button"
            onClick={addSocialLink}
            className="text-[#8349f0] hover:text-[#7340d9] text-sm font-medium flex items-center space-x-1"
          >
            <Plus className="h-4 w-4" />
            <span>Add Link</span>
          </button>
        </div>
        
        {formData.socialLinks.map((link) => (
          <div key={link.id} className="flex space-x-2 mb-3">
            <select
              value={link.platform}
              onChange={(e) => updateSocialLink(link.id, 'platform', e.target.value)}
              className="bg-white/50 backdrop-blur-sm border border-gray-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-[#8349f0]"
            >
              {socialPlatforms.map(platform => (
                <option key={platform} value={platform}>{platform}</option>
              ))}
            </select>
            <input
              type="url"
              value={link.url}
              onChange={(e) => updateSocialLink(link.id, 'url', e.target.value)}
              placeholder="Profile URL"
              className="flex-1 bg-white/50 backdrop-blur-sm border border-gray-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-[#8349f0]"
            />
            <button
              type="button"
              onClick={() => removeSocialLink(link.id)}
              className="text-red-500 hover:text-red-700 p-2"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>

      {/* Phone Number */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
        <input
          type="tel"
          value={formData.phoneNumber}
          onChange={(e) => handleInputChange('phoneNumber', e.target.value)}
          placeholder="+91 98765 43210"
          className={`w-full bg-white/50 backdrop-blur-sm border rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 ${
            formErrors.phoneNumber ? 'border-red-500' : 'border-gray-200'
          }`}
        />
        {formErrors.phoneNumber && <p className="text-red-500 text-sm mt-1">{formErrors.phoneNumber}</p>}
      </div>

      {/* Business Email */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Business Email *</label>
        <input
          type="email"
          value={formData.businessEmail}
          onChange={(e) => handleInputChange('businessEmail', e.target.value)}
          placeholder="business@email.com"
          className={`w-full bg-white/50 backdrop-blur-sm border rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 ${
            formErrors.businessEmail ? 'border-red-500' : 'border-gray-200'
          }`}
        />
        {formErrors.businessEmail && <p className="text-red-500 text-sm mt-1">{formErrors.businessEmail}</p>}
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Experience & Portfolio</h2>
      
      {/* Brands Collaborated With */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Brands Collaborated With</label>
        <div className="flex space-x-2 mb-3">
          <input
            type="text"
            value={formData.brandInput}
            onChange={(e) => handleInputChange('brandInput', e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addBrandTag())}
            placeholder="Enter brand name and press Enter"
            className="flex-1 bg-white/50 backdrop-blur-sm border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300"
          />
          <button
            type="button"
            onClick={addBrandTag}
            className="bg-[#8349f0] text-white px-4 py-3 rounded-xl hover:bg-[#7340d9] transition-colors duration-300"
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>
        
        {formData.brandsCollaborated.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {formData.brandsCollaborated.map((brand, index) => (
              <div key={index} className="bg-[#8349f0]/10 text-[#8349f0] px-3 py-1 rounded-full text-sm flex items-center space-x-2">
                <Tag className="h-3 w-3" />
                <span>{brand}</span>
                <button
                  type="button"
                  onClick={() => removeBrandTag(index)}
                  className="text-[#8349f0] hover:text-red-500"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Previous Work */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <label className="block text-sm font-medium text-gray-700">Previous Work</label>
          <button
            type="button"
            onClick={addPortfolioItem}
            className="text-[#8349f0] hover:text-[#7340d9] text-sm font-medium flex items-center space-x-1"
          >
            <Plus className="h-4 w-4" />
            <span>Add Work</span>
          </button>
        </div>
        
        {formData.portfolioItems.map((item) => (
          <div key={item.id} className="bg-white/50 backdrop-blur-sm border border-gray-200 rounded-xl p-4 mb-3">
            <div className="flex items-center justify-between mb-3">
              <div className="flex space-x-2">
                <button
                  type="button"
                  onClick={() => updatePortfolioItem(item.id, 'type', 'link')}
                  className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors duration-300 ${
                    item.type === 'link' 
                      ? 'bg-[#8349f0] text-white' 
                      : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                  }`}
                >
                  <Link className="h-4 w-4 inline mr-1" />
                  Link
                </button>
                <button
                  type="button"
                  onClick={() => updatePortfolioItem(item.id, 'type', 'upload')}
                  className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors duration-300 ${
                    item.type === 'upload' 
                      ? 'bg-[#8349f0] text-white' 
                      : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                  }`}
                >
                  <Upload className="h-4 w-4 inline mr-1" />
                  Upload
                </button>
              </div>
              <button
                type="button"
                onClick={() => removePortfolioItem(item.id)}
                className="text-red-500 hover:text-red-700"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input
                type="text"
                value={item.title}
                onChange={(e) => updatePortfolioItem(item.id, 'title', e.target.value)}
                placeholder="Work title"
                className="bg-white/50 backdrop-blur-sm border border-gray-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-[#8349f0]"
              />
              <input
                type="text"
                value={item.brandName}
                onChange={(e) => updatePortfolioItem(item.id, 'brandName', e.target.value)}
                placeholder="Brand name"
                className="bg-white/50 backdrop-blur-sm border border-gray-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-[#8349f0]"
              />
            </div>
            
            {item.type === 'link' ? (
              <input
                type="url"
                value={item.url || ''}
                onChange={(e) => updatePortfolioItem(item.id, 'url', e.target.value)}
                placeholder="https://example.com/your-work"
                className="w-full mt-3 bg-white/50 backdrop-blur-sm border border-gray-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-[#8349f0]"
              />
            ) : (
              <div className="mt-3">
                <input
                  type="file"
                  accept="image/*,video/*"
                  onChange={(e) => updatePortfolioItem(item.id, 'file', e.target.files?.[0])}
                  className="w-full bg-white/50 backdrop-blur-sm border border-gray-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-[#8349f0]"
                />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Overview Video */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Overview Video (Optional)</label>
        <input
          type="url"
          value={formData.overviewVideo}
          onChange={(e) => handleInputChange('overviewVideo', e.target.value)}
          placeholder="YouTube or Vimeo link"
          className="w-full bg-white/50 backdrop-blur-sm border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300"
        />
        <p className="text-xs text-gray-500 mt-1">This video will be displayed publicly on your profile</p>
      </div>

      {/* Areas of Expertise */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Areas of Expertise *</label>
        <div className="relative">
          <div
            onClick={() => setShowExpertiseDropdown(!showExpertiseDropdown)}
            className={`w-full bg-white/50 backdrop-blur-sm border rounded-xl py-3 px-4 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 ${
              formErrors.expertise ? 'border-red-500' : 'border-gray-200'
            }`}
          >
            {formData.expertise.length === 0 ? (
              <span className="text-gray-500">Select areas of expertise</span>
            ) : (
              <div className="flex flex-wrap gap-1">
                {formData.expertise.slice(0, 3).map((category) => (
                  <span key={category} className="bg-[#8349f0]/10 text-[#8349f0] px-2 py-1 rounded text-xs">
                    {category}
                  </span>
                ))}
                {formData.expertise.length > 3 && (
                  <span className="text-gray-500 text-xs">+{formData.expertise.length - 3} more</span>
                )}
              </div>
            )}
          </div>
          
          {showExpertiseDropdown && (
            <div className="absolute z-10 w-full mt-1 bg-white/90 backdrop-blur-md border border-gray-200 rounded-xl shadow-lg max-h-60 overflow-hidden">
              <div className="p-3 border-b border-gray-200">
                <input
                  type="text"
                  value={expertiseSearch}
                  onChange={(e) => setExpertiseSearch(e.target.value)}
                  placeholder="Search categories..."
                  className="w-full bg-white/50 border border-gray-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-[#8349f0] text-sm"
                />
              </div>
              <div className="max-h-40 overflow-y-auto">
                {filteredExpertise.map((category) => {
                  const isSelected = formData.expertise.includes(category);
                  
                  return (
                    <div
                      key={category}
                      onClick={() => toggleExpertise(category)}
                      className="flex items-center space-x-3 p-3 hover:bg-gray-50 cursor-pointer"
                    >
                      <div className={`w-4 h-4 border-2 rounded flex items-center justify-center ${
                        isSelected ? 'bg-[#8349f0] border-[#8349f0]' : 'border-gray-300'
                      }`}>
                        {isSelected && <Check className="h-3 w-3 text-white" />}
                      </div>
                      <span className="text-gray-700 text-sm">{category}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
        {formErrors.expertise && <p className="text-red-500 text-sm mt-1">{formErrors.expertise}</p>}
      </div>

      {/* Price Range */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Minimum Budget (₹) *</label>
        <input
          type="number"
          value={formData.minBudget}
          onChange={(e) => handleInputChange('minBudget', e.target.value)}
          placeholder="5000"
          min="0"
          className={`w-full bg-white/50 backdrop-blur-sm border rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 ${
            formErrors.minBudget ? 'border-red-500' : 'border-gray-200'
          }`}
        />
        {formErrors.minBudget && <p className="text-red-500 text-sm mt-1">{formErrors.minBudget}</p>}
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Profile Photo</h2>
      
      <div className="text-center">
        <div className="mb-6">
          {formData.profileImagePreview ? (
            <div className="relative inline-block">
              <img
                src={formData.profileImagePreview}
                alt="Profile preview"
                className="w-48 h-48 rounded-full object-cover border-4 border-[#8349f0]/20"
              />
              <button
                type="button"
                onClick={() => setFormData(prev => ({ ...prev, profileImage: null, profileImagePreview: '' }))}
                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors duration-300"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <div className="w-48 h-48 mx-auto bg-gray-100 rounded-full flex items-center justify-center border-2 border-dashed border-gray-300">
              <Camera className="h-12 w-12 text-gray-400" />
            </div>
          )}
        </div>
        
        <div className="mb-4">
          <label className="cursor-pointer">
            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
            <div className="bg-[#8349f0] text-white px-6 py-3 rounded-xl font-medium hover:bg-[#7340d9] transition-all duration-300 transform hover:scale-105 inline-flex items-center space-x-2">
              <Upload className="h-5 w-5" />
              <span>Upload Profile Image</span>
            </div>
          </label>
        </div>
        
        {formData.profileImagePreview && (
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-left">
            <h4 className="font-medium text-blue-900 mb-2">Image Cropping Tool</h4>
            <p className="text-blue-700 text-sm">
              In a production environment, this would integrate with a cropping library to allow users to crop their image to 200x200 pixels with real-time preview.
            </p>
          </div>
        )}
        
        {formErrors.profileImage && (
          <p className="text-red-500 text-sm mt-2">{formErrors.profileImage}</p>
        )}
      </div>
    </div>
  );

  if (submissionSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-purple-100 flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="h-10 w-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Profile Created Successfully!</h1>
          <p className="text-gray-600 mb-6">
            Your creator profile has been set up. You can now start receiving collaboration requests from brands.
          </p>
          <button
            onClick={() => window.location.href = '/creator/dashboard'}
            className="bg-[#8349f0] text-white px-6 py-3 rounded-xl font-medium hover:bg-[#7340d9] transition-all duration-300 transform hover:scale-105"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-purple-100">
      {/* Navigation */}
      <nav className="bg-white/70 backdrop-blur-md shadow-sm border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="bg-[#8349f0] p-2 rounded-lg">
                <Video className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-900">UGCKart</span>
            </div>
            
            <button
              onClick={handleBack}
              className="flex items-center space-x-2 text-gray-600 hover:text-[#8349f0] transition-colors duration-300"
            >
              <ArrowLeft className="h-5 w-5" />
              <span>Back</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="bg-white/60 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-8">
          {renderProgressBar()}
          
          {currentStep === 1 && renderStep1()}
          {currentStep === 2 && renderStep2()}
          {currentStep === 3 && renderStep3()}
          
          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
            <button
              onClick={handleBack}
              className="flex items-center space-x-2 text-gray-600 hover:text-[#8349f0] transition-colors duration-300"
            >
              <ArrowLeft className="h-5 w-5" />
              <span>Back</span>
            </button>
            
            {currentStep < 3 ? (
              <button
                onClick={handleNext}
                className="bg-[#8349f0] text-white px-6 py-3 rounded-xl font-medium hover:bg-[#7340d9] transition-all duration-300 transform hover:scale-105 flex items-center space-x-2"
              >
                <span>Save & Continue</span>
                <ArrowLeft className="h-5 w-5 rotate-180" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={isLoading}
                className="bg-[#8349f0] text-white px-6 py-3 rounded-xl font-medium hover:bg-[#7340d9] transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                {isLoading ? 'Creating Profile...' : 'Complete Profile'}
              </button>
            )}
          </div>
          
          {formErrors.submit && (
            <div className="mt-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-xl">
              {formErrors.submit}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreatorProfile;