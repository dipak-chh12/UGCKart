import React, { useState } from 'react';
import { ShoppingCart, Search, Users, MessageCircle, ArrowRight, Video, Menu, X, Briefcase, User, Eye, EyeOff } from 'lucide-react';
import CreatorProfile from './components/CreatorProfile';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Authentication state
  const [userType, setUserType] = useState('creator');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);
  
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    username: '',
    password: '',
    confirmPassword: ''
  });
  
  const [formErrors, setFormErrors] = useState({});

  // Form validation functions
  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePhone = (phone) => {
    const phoneRegex = /^[+]?[\d\s\-\(\)]{10,}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
  };

  const validatePassword = (password) => {
    const minLength = password.length >= 8;
    const hasUppercase = /[A-Z]/.test(password);
    const hasLowercase = /[a-z]/.test(password);
    const hasNumber = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    return {
      isValid: minLength && hasUppercase && hasLowercase && hasNumber && hasSpecialChar,
      minLength,
      hasUppercase,
      hasLowercase,
      hasNumber,
      hasSpecialChar
    };
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (formErrors[field]) {
      setFormErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const newErrors = {};
    
    // Validate required fields
    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!validateEmail(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!validatePhone(formData.phone)) {
      newErrors.phone = 'Please enter a valid phone number';
    }
    
    if (!formData.username.trim()) {
      newErrors.username = 'Username is required';
    } else if (formData.username.length < 3) {
      newErrors.username = 'Username must be at least 3 characters';
    }
    
    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else {
      const passwordValidation = validatePassword(formData.password);
      if (!passwordValidation.isValid) {
        newErrors.password = 'Password must be at least 8 characters with uppercase, lowercase, number, and special character';
      }
    }
    
    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }
    
    if (Object.keys(newErrors).length > 0) {
      setFormErrors(newErrors);
      return;
    }
    
    // Simulate API call
    setIsLoading(true);
    setFormErrors({});
    
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      setSubmissionSuccess(true);
      
      // Simulate redirect after success
      setTimeout(() => {
        const redirectPath = userType === 'creator' ? '/creator/create-profile' : '/brand/create-profile';
        console.log(`Redirecting to: ${redirectPath}`);
        
        // Redirect to creator profile page if creator is selected
        if (userType === 'creator') {
          setCurrentPage('creatorProfile');
        } else {
          // For brands, we'll implement this later
          console.log('Brand profile creation coming soon');
        }
      }, 1500);
      
    } catch (error) {
      setFormErrors({ submit: 'Something went wrong. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const renderSignupPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-purple-100 relative">
      {/* Navigation */}
      <nav className="bg-white/70 backdrop-blur-md shadow-sm border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center space-x-2 cursor-pointer" onClick={() => setCurrentPage('home')}>
              <div className="bg-[#8349f0] p-2 rounded-lg">
                <Video className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-900">UGCKart</span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-3">
              <button 
                onClick={() => setCurrentPage('login')}
                className="text-gray-700 hover:text-[#8349f0] font-medium transition-colors duration-300 px-4 py-1.5"
              >
                Login
              </button>
              <button className="bg-[#8349f0] text-white px-5 py-1.5 rounded-lg font-medium hover:bg-[#7340d9] transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                Sign Up
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-gray-700 hover:text-[#8349f0] transition-colors duration-300"
              >
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden bg-white/90 backdrop-blur-md border-t border-white/20 py-4">
              <div className="flex flex-col space-y-3">
                <button 
                  onClick={() => setCurrentPage('login')}
                  className="text-gray-700 hover:text-[#8349f0] font-medium transition-colors duration-300 px-4 py-2 text-left"
                >
                  Login
                </button>
                <button className="bg-[#8349f0] text-white px-4 py-2 rounded-lg font-medium hover:bg-[#7340d9] transition-all duration-300 mx-4">
                  Sign Up
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Signup Form */}
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)] px-4 py-12">
        <div className="w-full max-w-md">
          {submissionSuccess ? (
            <div className="text-center">
              <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-xl mb-6">
                <h3 className="font-semibold">Account Created Successfully!</h3>
                <p className="text-sm mt-1">
                  Redirecting to {userType === 'creator' ? '/creator/create-profile' : '/brand/create-profile'}...
                </p>
              </div>
            </div>
          ) : (
            <>
              {/* Logo and Welcome */}
              <div className="text-center mb-8">
                <div className="bg-[#8349f0] w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Video className="h-8 w-8 text-white" />
                </div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Join UGCKart</h1>
                <p className="text-gray-600">Create your account to get started</p>
              </div>

              {/* User Type Selection */}
              <div className="bg-white/60 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-6 mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 text-center">I am a...</h3>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setUserType('creator')}
                    className={`p-4 rounded-xl border-2 transition-all duration-300 flex flex-col items-center space-y-2 ${
                      userType === 'creator'
                        ? 'border-[#8349f0] bg-[#8349f0]/10 text-[#8349f0]'
                        : 'border-gray-200 bg-white/50 text-gray-600 hover:border-[#8349f0]/50'
                    }`}
                  >
                    <User className="h-8 w-8" />
                    <span className="font-medium">Creator</span>
                  </button>
                  
                  <button
                    type="button"
                    onClick={() => setUserType('brand')}
                    className={`p-4 rounded-xl border-2 transition-all duration-300 flex flex-col items-center space-y-2 ${
                      userType === 'brand'
                        ? 'border-[#8349f0] bg-[#8349f0]/10 text-[#8349f0]'
                        : 'border-gray-200 bg-white/50 text-gray-600 hover:border-[#8349f0]/50'
                    }`}
                  >
                    <Briefcase className="h-8 w-8" />
                    <span className="font-medium">Brand</span>
                  </button>
                </div>
              </div>

              {/* Signup Form */}
              <form onSubmit={handleSubmit} className="bg-white/60 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-8">
                {/* Google Sign Up */}
                <button 
                  type="button"
                  className="w-full bg-white/80 backdrop-blur-sm border border-gray-200 rounded-xl py-3 px-4 flex items-center justify-center space-x-3 hover:bg-white/90 transition-all duration-300 mb-6 shadow-sm hover:shadow-md"
                >
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                  <span className="text-gray-700 font-medium">Sign up with Google</span>
                </button>

                {/* Divider */}
                <div className="relative mb-6">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-200"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-4 bg-white/60 text-gray-500">Or continue with email</span>
                  </div>
                </div>

                {/* Full Name */}
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                  <input
                    type="text"
                    value={formData.fullName}
                    onChange={(e) => handleInputChange('fullName', e.target.value)}
                    placeholder="Enter your full name"
                    className={`w-full bg-white/50 backdrop-blur-sm border rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 placeholder-gray-400 ${
                      formErrors.fullName ? 'border-red-500' : 'border-gray-200'
                    }`}
                  />
                  {formErrors.fullName && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.fullName}</p>
                  )}
                </div>

                {/* Email */}
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    placeholder="your@email.com"
                    className={`w-full bg-white/50 backdrop-blur-sm border rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 placeholder-gray-400 ${
                      formErrors.email ? 'border-red-500' : 'border-gray-200'
                    }`}
                  />
                  {formErrors.email && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.email}</p>
                  )}
                </div>

                {/* Phone Number */}
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    placeholder="+1 (555) 123-4567"
                    className={`w-full bg-white/50 backdrop-blur-sm border rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 placeholder-gray-400 ${
                      formErrors.phone ? 'border-red-500' : 'border-gray-200'
                    }`}
                  />
                  {formErrors.phone && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.phone}</p>
                  )}
                </div>

                {/* Username */}
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
                  <input
                    type="text"
                    value={formData.username}
                    onChange={(e) => handleInputChange('username', e.target.value)}
                    placeholder="Choose a username"
                    className={`w-full bg-white/50 backdrop-blur-sm border rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 placeholder-gray-400 ${
                      formErrors.username ? 'border-red-500' : 'border-gray-200'
                    }`}
                  />
                  {formErrors.username && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.username}</p>
                  )}
                </div>

                {/* Password */}
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={formData.password}
                      onChange={(e) => handleInputChange('password', e.target.value)}
                      placeholder="Create a strong password"
                      className={`w-full bg-white/50 backdrop-blur-sm border rounded-xl py-3 px-4 pr-12 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 placeholder-gray-400 ${
                        formErrors.password ? 'border-red-500' : 'border-gray-200'
                      }`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    >
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                  {formErrors.password && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.password}</p>
                  )}
                </div>

                {/* Confirm Password */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Confirm Password</label>
                  <div className="relative">
                    <input
                      type={showConfirmPassword ? 'text' : 'password'}
                      value={formData.confirmPassword}
                      onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                      placeholder="Confirm your password"
                      className={`w-full bg-white/50 backdrop-blur-sm border rounded-xl py-3 px-4 pr-12 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 placeholder-gray-400 ${
                        formErrors.confirmPassword ? 'border-red-500' : 'border-gray-200'
                      }`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    >
                      {showConfirmPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                  {formErrors.confirmPassword && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.confirmPassword}</p>
                  )}
                </div>

                {/* Submit Error */}
                {formErrors.submit && (
                  <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-xl">
                    {formErrors.submit}
                  </div>
                )}

                {/* Sign Up Button */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-[#8349f0] text-white py-3 px-4 rounded-xl font-semibold hover:bg-[#7340d9] transition-all duration-300 transform hover:scale-[1.02] shadow-lg hover:shadow-xl mb-6 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                >
                  {isLoading ? 'Creating Account...' : 'Sign Up'}
                </button>

                {/* Login Link */}
                <p className="text-center text-gray-600">
                  Already have an account?{' '}
                  <button 
                    type="button"
                    onClick={() => setCurrentPage('login')}
                    className="text-[#8349f0] font-semibold hover:text-[#7340d9] transition-colors duration-300"
                  >
                    Sign in
                  </button>
                </p>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );

  const renderLoginPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-purple-100 relative">
      {/* Navigation */}
      <nav className="bg-white/70 backdrop-blur-md shadow-sm border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center space-x-2 cursor-pointer" onClick={() => setCurrentPage('home')}>
              <div className="bg-[#8349f0] p-2 rounded-lg">
                <Video className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-900">UGCKart</span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-3">
              <button className="text-gray-700 hover:text-[#8349f0] font-medium transition-colors duration-300 px-4 py-1.5">
                Login
              </button>
              <button 
                onClick={() => setCurrentPage('signup')}
                className="bg-[#8349f0] text-white px-5 py-1.5 rounded-lg font-medium hover:bg-[#7340d9] transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
              >
                Sign Up
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-gray-700 hover:text-[#8349f0] transition-colors duration-300"
              >
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden bg-white/90 backdrop-blur-md border-t border-white/20 py-4">
              <div className="flex flex-col space-y-3">
                <button className="text-gray-700 hover:text-[#8349f0] font-medium transition-colors duration-300 px-4 py-2 text-left">
                  Login
                </button>
                <button 
                  onClick={() => setCurrentPage('signup')}
                  className="bg-[#8349f0] text-white px-4 py-2 rounded-lg font-medium hover:bg-[#7340d9] transition-all duration-300 mx-4"
                >
                  Sign Up
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Login Form */}
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)] px-4 py-12">
        <div className="w-full max-w-md">
          {/* Logo and Welcome */}
          <div className="text-center mb-8">
            <div className="bg-[#8349f0] w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Video className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome Back</h1>
            <p className="text-gray-600">Sign in to your account</p>
          </div>

          {/* Login Form */}
          <div className="bg-white/60 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-8">
            {/* Google Sign In */}
            <button className="w-full bg-white/80 backdrop-blur-sm border border-gray-200 rounded-xl py-3 px-4 flex items-center justify-center space-x-3 hover:bg-white/90 transition-all duration-300 mb-6 shadow-sm hover:shadow-md">
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              <span className="text-gray-700 font-medium">Sign in with Google</span>
            </button>

            {/* Divider */}
            <div className="relative mb-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-4 bg-white/60 text-gray-500">Or continue with email</span>
              </div>
            </div>

            {/* Email Input */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <input
                type="email"
                placeholder="your@email.com"
                className="w-full bg-white/50 backdrop-blur-sm border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 placeholder-gray-400"
              />
            </div>

            {/* Password Input */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
              <input
                type="password"
                placeholder="••••••••"
                className="w-full bg-white/50 backdrop-blur-sm border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-[#8349f0] focus:border-transparent transition-all duration-300 placeholder-gray-400"
              />
            </div>

            {/* Sign In Button */}
            <button className="w-full bg-[#8349f0] text-white py-3 px-4 rounded-xl font-semibold hover:bg-[#7340d9] transition-all duration-300 transform hover:scale-[1.02] shadow-lg hover:shadow-xl mb-6">
              Sign In
            </button>

            {/* Sign Up Link */}
            <p className="text-center text-gray-600">
              Don't have an account?{' '}
              <button 
                onClick={() => setCurrentPage('signup')}
                className="text-[#8349f0] font-semibold hover:text-[#7340d9] transition-colors duration-300"
              >
                Sign up
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderHomePage = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-purple-100 relative">
      {/* Navigation */}
      <nav className="bg-white/70 backdrop-blur-md shadow-sm border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center space-x-2">
              <div className="bg-[#8349f0] p-2 rounded-lg">
                <ShoppingCart className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-900">UGCKart</span>
            </div>
            
            {/* Navigation Links */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#" className="text-gray-700 hover:text-[#8349f0] font-medium transition-colors duration-300">
                Home
              </a>
              <a href="#" className="text-gray-700 hover:text-[#8349f0] font-medium transition-colors duration-300">
                Find Creators
              </a>
              <a href="#" className="text-gray-700 hover:text-[#8349f0] font-medium transition-colors duration-300">
                For Brands
              </a>
            </div>
            
            {/* Auth Buttons */}
            <div className="hidden md:flex items-center space-x-3">
              <button 
                onClick={() => setCurrentPage('login')}
                className="text-gray-700 hover:text-[#8349f0] font-medium transition-colors duration-300 px-4 py-1.5"
              >
                Login
              </button>
              <button 
                onClick={() => setCurrentPage('signup')}
                className="bg-[#8349f0] text-white px-5 py-1.5 rounded-lg font-medium hover:bg-[#7340d9] transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
              >
                Sign Up
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-gray-700 hover:text-[#8349f0] transition-colors duration-300"
              >
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden bg-white/90 backdrop-blur-md border-t border-white/20 py-4">
              <div className="flex flex-col space-y-3">
                <a href="#" className="text-gray-700 hover:text-[#8349f0] font-medium transition-colors duration-300 px-4 py-2">
                  Home
                </a>
                <a href="#" className="text-gray-700 hover:text-[#8349f0] font-medium transition-colors duration-300 px-4 py-2">
                  Find Creators
                </a>
                <a href="#" className="text-gray-700 hover:text-[#8349f0] font-medium transition-colors duration-300 px-4 py-2">
                  For Brands
                </a>
                <button 
                  onClick={() => setCurrentPage('login')}
                  className="text-gray-700 hover:text-[#8349f0] font-medium transition-colors duration-300 px-4 py-2 text-left"
                >
                  Login
                </button>
                <button 
                  onClick={() => setCurrentPage('signup')}
                  className="bg-[#8349f0] text-white px-4 py-2 rounded-lg font-medium hover:bg-[#7340d9] transition-all duration-300 mx-4"
                >
                  Sign Up
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Connect with India's Best
            <br />
            <span className="text-[#8349f0]">UGC Creators</span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto leading-relaxed">
            The premier marketplace for brands to find authentic UGC creators and for creators to
            discover exciting brand partnerships. No middleman, direct communication.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button 
              onClick={() => setCurrentPage('signup')}
              className="bg-[#8349f0] text-white px-6 py-3 rounded-lg font-semibold text-base hover:bg-[#7340d9] transition-all duration-300 transform hover:scale-105 flex items-center space-x-2 shadow-lg hover:shadow-xl"
            >
              <span>Get Started as Creator</span>
              <ArrowRight className="h-4 w-4" />
            </button>
            <button 
              onClick={() => setCurrentPage('signup')}
              className="bg-white/80 backdrop-blur-sm text-[#8349f0] px-6 py-3 rounded-lg font-semibold text-base border-2 border-[#8349f0] hover:bg-[#8349f0] hover:text-white transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
            >
              Find Creators for Your Brand
            </button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white/40 backdrop-blur-md border-y border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="group">
              <div className="text-5xl font-bold text-[#8349f0] mb-2 group-hover:scale-110 transition-transform duration-300">
                500+
              </div>
              <div className="text-xl text-gray-600 font-medium">Verified Creators</div>
            </div>
            
            <div className="group">
              <div className="text-5xl font-bold text-[#8349f0] mb-2 group-hover:scale-110 transition-transform duration-300">
                200+
              </div>
              <div className="text-xl text-gray-600 font-medium">Happy Brands</div>
            </div>
            
            <div className="group">
              <div className="text-5xl font-bold text-[#8349f0] mb-2 group-hover:scale-110 transition-transform duration-300">
                1000+
              </div>
              <div className="text-xl text-gray-600 font-medium">Projects Completed</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose UGCKart?
            </h2>
            <p className="text-xl text-[#8349f0] font-medium">
              Everything you need to create successful UGC campaigns
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Smart Matching */}
            <div className="bg-white/60 backdrop-blur-md p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group border border-white/20">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mb-6 group-hover:bg-[#8349f0] transition-colors duration-300">
                <Search className="h-8 w-8 text-[#8349f0] group-hover:text-white transition-colors duration-300" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Smart Matching</h3>
              <p className="text-gray-600 leading-relaxed">
                Find the perfect creators for your brand using our AI-powered matching system.
              </p>
            </div>
            
            {/* Verified Creators */}
            <div className="bg-white/60 backdrop-blur-md p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group border border-white/20">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mb-6 group-hover:bg-[#8349f0] transition-colors duration-300">
                <Users className="h-8 w-8 text-[#8349f0] group-hover:text-white transition-colors duration-300" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Verified Creators</h3>
              <p className="text-gray-600 leading-relaxed">
                All creators are verified with portfolios and testimonials for quality assurance.
              </p>
            </div>
            
            {/* Direct Communication */}
            <div className="bg-white/60 backdrop-blur-md p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group border border-white/20">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mb-6 group-hover:bg-[#8349f0] transition-colors duration-300">
                <MessageCircle className="h-8 w-8 text-[#8349f0] group-hover:text-white transition-colors duration-300" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Direct Communication</h3>
              <p className="text-gray-600 leading-relaxed">
                Connect directly with creators through our built-in messaging system. No middleman.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#8349f0]/95 backdrop-blur-md relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Start Your UGC Journey?
          </h2>
          <p className="text-xl text-purple-100 mb-10 max-w-2xl mx-auto">
            Join thousands of brands and creators who trust UGCKart for their content marketing needs.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button 
              onClick={() => setCurrentPage('signup')}
              className="bg-white text-[#8349f0] px-6 py-3 rounded-lg font-semibold text-base hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
            >
              Join as Creator
            </button>
            <button 
              onClick={() => setCurrentPage('signup')}
              className="bg-transparent text-white px-6 py-3 rounded-lg font-semibold text-base border-2 border-white hover:bg-white hover:text-[#8349f0] transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
            >
              Post a Project
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900/95 backdrop-blur-md py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="bg-[#8349f0] p-2 rounded-lg">
                <ShoppingCart className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-white">UGCKart</span>
            </div>
            
            <div className="flex space-x-8 text-gray-400">
              <a href="#" className="hover:text-white transition-colors duration-300">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors duration-300">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors duration-300">Contact</a>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 UGCKart. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );

  // Page routing
  if (currentPage === 'signup') {
    return renderSignupPage();
  } else if (currentPage === 'creatorProfile') {
    return <CreatorProfile onBack={() => setCurrentPage('signup')} />;
  } else if (currentPage === 'login') {
    return renderLoginPage();
  } else {
    return renderHomePage();
  }
}

export default App;